package com.whendy.brbinder.ui.gallery;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.whendy.brbinder.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;
    private int groupIndex = 0; // Индекс активной группы
    private int commandIndex = 0; // Индекс текущей команды в группе
    private String[][] commands = {
            { // Группа 1: Авто-Парк
                    "/s Здравия желаю уважаемые сотрудники.",
                    "/s Сейчас состоится лекция на тему \"Правила Автопарка\".",
                    "/s Запрещено оставлять фракционное авто не на парковке отдела ГИБДД.",
                    "/s Запрещено брать фракционное авто и давать им пользоваться сотрудникам рангом ниже доступного к взятию этой машины.",
                    "/s Запрещено использовать фракционное авто в личных целях. Исключение: забрать напарника если тот оказался в больнице.",
                    "/s Запрещено перевозить гражданский без причины на фракционном авто.",
                    "/s За нарушение правил Автопарка, вы будете наказаны выговором, либо же будете уволены.",
                    "/s Лекция на тему \"Правила Автопарка\" окончена!"
            },
            { // Группа 2: Правила поведения в строю
                    "/s Здравия желаю уважаемые сотрудники.",
                    "/s Сейчас будет лекция на тему \"Правила поведения в строю\".",
                    "/s В строю запрещено: курить, приседать, крутиться, бегать, говорить по телефону, разговаривать в строю.",
                    "/s Оскорблять коллег, перебивать говорящего, выбегать из строя без разрешения старшего.",
                    "/s За нарушение правил поведения в строю, вы будете наказаны выговором, или же будете уволены.",
                    "Лекция на тему \"Правила поведения в строю\" окончена!"
            },
            { // Группа 3: Обязонности сотрудника ГИБДД
                    "/s Здравия желаю, уважаемые сотрудники!",
                    "/s Сегодня я проведу лекцию, не тему \"Обязанности сотрудника ГИБДД\".",
                    "/s Каждый сотрудник обязан соблюдать субординацию.",
                    "/s Каждый сотрудник обязан подчиняться Уставу и следовать УК РФ.",
                    "/s Сотрудник ГИБДД обязан вести себя адекватно в сторону любого сотрудника организации.",
                    "/s Сотрудник ГИБДД обязан выдавать розыск с указанием номера статьи УК РФ.",
                    "/s На этом наша лекция подходит к концу"
            },
            { // Группа 4: Правила рации
                    "/s Сейчас я проведу лекцию на тему \"Рация\".",
                    "/s Рация - это источник связи с сотрудниками и передачи важной информации.",
                    "/s В раций звучит такая информация, как доклады с постом и тому подобное",
                    "/s В рацию запрещены: оскорбления, маты и угрозы.",
                    "/s В рацию запрещено сообщать бессмысленные сообщения.",
                    "/s За нарушение данных правил Вы будете наказаны.",
                    "/s На этом наша лекция подошла к концу."
            }
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        GalleryViewModel galleryViewModel =
                new ViewModelProvider(this).get(GalleryViewModel.class);

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Инициализация кнопок
        Button autoParkKapitan = binding.autoParkKapitan;
        Button pravilaPovedenieStroiKapitan = binding.pravilaPovedenieStroiKapitan;
        Button obizonoctiSotrydnikaGidbb = binding.obizonoctiSotrydnikaGidbb;
        Button pravilaRaciGidbb = binding.pravilaRaciGidbb;

        // Обработчик нажатия на кнопку "Авто-Парк"
        autoParkKapitan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                groupIndex = 0; // Устанавливаем индекс группы Авто-Парк
                String currentCommand = commands[groupIndex][commandIndex];
                if (v.getAlpha() == 1 && !currentCommand.isEmpty()) { // Проверка на видимость кнопки
                    ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("command", currentCommand);
                    clipboard.setPrimaryClip(clip);
                    commandIndex = (commandIndex + 1) % commands[groupIndex].length; // Переходим к следующей команде в группе
                }
            }
        });

        // Обработчик нажатия на кнопку "Правила поведения в строю"
        pravilaPovedenieStroiKapitan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                groupIndex = 1; // Устанавливаем индекс группы Правил поведения в строю
                String currentCommand = commands[groupIndex][commandIndex];
                if (v.getAlpha() == 1 && !currentCommand.isEmpty()) { // Проверка на видимость кнопки
                    ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("command", currentCommand);
                    clipboard.setPrimaryClip(clip);
                    commandIndex = (commandIndex + 1) % commands[groupIndex].length; // Переходим к следующей команде в группе
                }
            }
        });

        // Обработчик нажатия на кнопку "Обязоности сотрудника ГИБДД"
        obizonoctiSotrydnikaGidbb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                groupIndex = 2; // Устанавливаем индекс группы Авто-Парк
                String currentCommand = commands[groupIndex][commandIndex];
                if (v.getAlpha() == 1 && !currentCommand.isEmpty()) { // Проверка на видимость кнопки
                    ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("command", currentCommand);
                    clipboard.setPrimaryClip(clip);
                    commandIndex = (commandIndex + 1) % commands[groupIndex].length; // Переходим к следующей команде в группе
                }
            }
        });

        // Обработчик нажатия на кнопку "Правила рации"
        pravilaRaciGidbb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                groupIndex = 3; // Устанавливаем индекс группы Авто-Парк
                String currentCommand = commands[groupIndex][commandIndex];
                if (v.getAlpha() == 1 && !currentCommand.isEmpty()) { // Проверка на видимость кнопки
                    ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("command", currentCommand);
                    clipboard.setPrimaryClip(clip);
                    commandIndex = (commandIndex + 1) % commands[groupIndex].length; // Переходим к следующей команде в группе
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}