package com.whendy.brbinder.ui.home;

import androidx.fragment.app.Fragment;
import com.whendy.brbinder.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}